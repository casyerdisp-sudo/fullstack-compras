from fastapi import APIRouter, Depends, HTTPException
from typing import Optional, List
from ..models import SolicitudCreate, SolicitudItem
from ..repositories.solicitudes_repo import SolicitudesRepo
from ..deps import get_current_user, UserContext

router = APIRouter(prefix="/solicitudes", tags=["solicitudes"])
repo = SolicitudesRepo()

@router.post('', status_code=201)
def crear_solicitud(body: SolicitudCreate, user: UserContext = Depends(get_current_user)):
    try:
        new_id = repo.crear(user.username, body.descripcion, body.monto, body.fecha_esperada)
        return {"id": new_id}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get('', response_model=List[SolicitudItem])
def listar_mias(estado: Optional[str] = None, user: UserContext = Depends(get_current_user)):
    data = repo.listar(user.username, estado)
    return [SolicitudItem(**{
        'id': d['Id'], 'username': d['Username'], 'descripcion': d['Descripcion'], 'monto': float(d['Monto']),
        'fecha_esperada': str(d['FechaEsperada']), 'estado': d['Estado'],
        'comentario_supervisor': d['ComentarioSupervisor'],
        'fecha_creacion': str(d['FechaCreacion']), 'fecha_actualizacion': str(d['FechaActualizacion']) if d['FechaActualizacion'] else None
    }) for d in data]
