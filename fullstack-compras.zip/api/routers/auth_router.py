from fastapi import APIRouter, HTTPException
from ..models import LoginRequest, TokenResponse
from ..repositories.solicitudes_repo import SolicitudesRepo
from ..auth import create_token

router = APIRouter(prefix="/auth", tags=["auth"])
repo = SolicitudesRepo()

@router.post('/login', response_model=TokenResponse)
def login(body: LoginRequest):
    try:
        user = repo.login(body.username, body.password)
        token = create_token(user['Username'], user['Rol'])
        return TokenResponse(access_token=token, username=user['Username'], role=user['Rol'])
    except Exception as e:
        raise HTTPException(status_code=401, detail=str(e))
