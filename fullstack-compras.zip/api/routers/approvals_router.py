from fastapi import APIRouter, Depends, HTTPException
from typing import Optional
from ..repositories.solicitudes_repo import SolicitudesRepo
from ..deps import require_role, UserContext

router = APIRouter(prefix="/approvals", tags=["approvals"])
repo = SolicitudesRepo()

@router.post('/{solicitud_id}/approve')
def aprobar(solicitud_id: int, comentario: Optional[str] = None, user: UserContext = Depends(require_role('Supervisor'))):
    try:
        repo.aprobar(user.username, solicitud_id, comentario)
        return {"ok": True}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post('/{solicitud_id}/reject')
def rechazar(solicitud_id: int, comentario: Optional[str] = None, user: UserContext = Depends(require_role('Supervisor'))):
    try:
        repo.rechazar(user.username, solicitud_id, comentario)
        return {"ok": True}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
