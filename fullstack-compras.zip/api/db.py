import pyodbc
from .config import SQLSERVER_CONN

def get_conn():
    return pyodbc.connect(SQLSERVER_CONN)
