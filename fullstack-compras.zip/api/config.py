import os
JWT_SECRET = os.getenv('JWT_SECRET', 'dev-secret-change')
JWT_ALG = 'HS256'
SQLSERVER_CONN = os.getenv('SQLSERVER_CONN')
