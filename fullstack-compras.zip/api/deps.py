from fastapi import Header, HTTPException, status, Depends
from .auth import decode_token

class UserContext:
    def __init__(self, username: str, role: str):
        self.username = username
        self.role = role

def get_current_user(authorization: str = Header(None)) -> UserContext:
    if not authorization or not authorization.lower().startswith('bearer '):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail='Token faltante')
    token = authorization.split(' ')[1]
    try:
        data = decode_token(token)
        return UserContext(username=data['sub'], role=data['role'])
    except Exception:
        raise HTTPException(status_code=401, detail='Token inválido')

def require_role(required: str):
    def _inner(user: UserContext = Depends(get_current_user)):
        if user.role != required:
            raise HTTPException(status_code=403, detail='Permisos insuficientes')
        return user
    return _inner
