import time, os, pyodbc, pathlib

conn_str = os.getenv("SQLSERVER_CONN")
sql_path = pathlib.Path("/app").parent / "db" / "solicitudes.sql"

# Espera a que SQL esté listo
for i in range(60):
    try:
        with pyodbc.connect(conn_str, timeout=2) as c:
            break
    except Exception:
        time.sleep(2)
else:
    raise RuntimeError("SQL Server no disponible")

with open(sql_path, "r", encoding="utf-8") as f:
    sql = f.read()

# Ejecutar el script con separador GO
chunks, acc = [], []
for line in sql.splitlines():
    if line.strip().upper() == "GO":
        chunks.append("\n".join(acc)); acc=[]
    else:
        acc.append(line)
if acc: chunks.append("\n".join(acc))

with pyodbc.connect(conn_str, autocommit=True) as conn:
    cur = conn.cursor()
    for ch in chunks:
        if ch.strip():
            try:
                cur.execute(ch)
            except Exception as e:
                # idempotencia
                pass
