import time, jwt
from .config import JWT_SECRET, JWT_ALG

def create_token(username: str, role: str):
    payload = {"sub": username, "role": role, "iat": int(time.time()), "exp": int(time.time()) + 3600}
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALG)

def decode_token(token: str):
    return jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALG])
