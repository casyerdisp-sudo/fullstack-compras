from pydantic import BaseModel, Field
from typing import Optional

class LoginRequest(BaseModel):
    username: str
    password: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = 'bearer'
    username: str
    role: str

class SolicitudCreate(BaseModel):
    descripcion: str = Field(min_length=3, max_length=500)
    monto: float = Field(gt=0)
    fecha_esperada: str  # YYYY-MM-DD

class SolicitudItem(BaseModel):
    id: int
    username: str
    descripcion: str
    monto: float
    fecha_esperada: str
    estado: str
    comentario_supervisor: Optional[str] = None
    fecha_creacion: str
    fecha_actualizacion: Optional[str] = None
