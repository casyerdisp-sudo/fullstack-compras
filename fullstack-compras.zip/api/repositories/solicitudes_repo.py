from typing import List, Optional, Dict, Any
from ..db import get_conn

class SolicitudesRepo:
    def login(self, username: str, password: str) -> Dict[str, Any]:
        with get_conn() as conn:
            cur = conn.cursor()
            try:
                cur.execute("EXEC dbo.sp_login @Username=?, @Password=?", (username, password))
                row = cur.fetchone()
                return {"Id": row[0], "Rol": row[1], "Username": row[2]}
            except Exception as e:
                raise e

    def crear(self, username: str, descripcion: str, monto: float, fecha_esperada: str) -> int:
        with get_conn() as conn:
            cur = conn.cursor()
            cur.execute("EXEC dbo.sp_crear_solicitud @Username=?, @Descripcion=?, @Monto=?, @FechaEsperada=?",
                        (username, descripcion, monto, fecha_esperada))
            row = cur.fetchone()
            return int(row[0])

    def listar(self, username: str, estado: Optional[str]=None) -> List[Dict[str, Any]]:
        with get_conn() as conn:
            cur = conn.cursor()
            if estado:
                cur.execute("EXEC dbo.sp_listar_solicitudes @Username=?, @Estado=?", (username, estado))
            else:
                cur.execute("EXEC dbo.sp_listar_solicitudes @Username=?", (username,))
            cols = [c[0] for c in cur.description]
            return [dict(zip(cols, row)) for row in cur.fetchall()]

    def aprobar(self, supervisor_username: str, solicitud_id: int, comentario: Optional[str]) -> None:
        with get_conn() as conn:
            cur = conn.cursor()
            cur.execute("EXEC dbo.sp_aprobar_solicitud @SupervisorUsername=?, @SolicitudId=?, @Comentario=?",
                        (supervisor_username, solicitud_id, comentario))

    def rechazar(self, supervisor_username: str, solicitud_id: int, comentario: Optional[str]) -> None:
        with get_conn() as conn:
            cur = conn.cursor()
            cur.execute("EXEC dbo.sp_rechazar_solicitud @SupervisorUsername=?, @SolicitudId=?, @Comentario=?",
                        (supervisor_username, solicitud_id, comentario))
