from fastapi import FastAPI
from .routers.auth_router import router as auth
from .routers.solicitudes_router import router as solicitudes
from .routers.approvals_router import router as approvals

app = FastAPI(title='Solicitudes de Compra API')
app.include_router(auth)
app.include_router(solicitudes)
app.include_router(approvals)
