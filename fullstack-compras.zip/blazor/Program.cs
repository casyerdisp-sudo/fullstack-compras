using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Web;
using Blazored.LocalStorage;
using BlazorApp.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor();
builder.Services.AddBlazoredLocalStorage();

var apiBase = Environment.GetEnvironmentVariable("API_BASE") ?? "http://localhost:8000";
builder.Services.AddHttpClient<ApiClient>(client => {
    client.BaseAddress = new Uri(apiBase.EndsWith("/") ? apiBase : apiBase + "/");
});

var app = builder.Build();
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
}
app.UseStaticFiles();
app.UseRouting();
app.MapBlazorHub();
app.MapFallbackToPage("/_Host");
app.Run();
