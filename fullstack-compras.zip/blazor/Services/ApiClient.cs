using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using Blazored.LocalStorage;

namespace BlazorApp.Services
{
    public class ApiClient
    {
        private readonly HttpClient _http;
        private readonly ILocalStorageService _storage;
        public ApiClient(HttpClient http, ILocalStorageService storage)
        { _http = http; _storage = storage; }

        private async Task AttachToken()
        {
            var token = await _storage.GetItemAsStringAsync("token");
            if (!string.IsNullOrEmpty(token))
                _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
        }

        public record LoginReq(string username, string password);
        public record LoginRes(string access_token, string token_type, string username, string role);

        public async Task<LoginRes?> Login(string user, string pass)
        {
            var json = JsonSerializer.Serialize(new LoginReq(user, pass));
            var res = await _http.PostAsync("auth/login", new StringContent(json, Encoding.UTF8, "application/json"));
            if (!res.IsSuccessStatusCode) return null;
            var body = await res.Content.ReadAsStringAsync();
            return JsonSerializer.Deserialize<LoginRes>(body, new JsonSerializerOptions{PropertyNameCaseInsensitive=true});
        }

        public record SolicitudCreate(string descripcion, decimal monto, string fecha_esperada);

        public async Task<bool> CrearSolicitud(SolicitudCreate req)
        {
            await AttachToken();
            var json = JsonSerializer.Serialize(req);
            var res = await _http.PostAsync("solicitudes", new StringContent(json, Encoding.UTF8, "application/json"));
            return res.IsSuccessStatusCode;
        }

        public class SolicitudItem {
            public int id {get;set;}
            public string username {get;set;} = string.Empty;
            public string descripcion {get;set;} = string.Empty;
            public decimal monto {get;set;}
            public string fecha_esperada {get;set;} = string.Empty;
            public string estado {get;set;} = string.Empty;
            public string? comentario_supervisor {get;set;}
            public string fecha_creacion {get;set;} = string.Empty;
            public string? fecha_actualizacion {get;set;}
        }

        public async Task<List<SolicitudItem>> Listar(string? estado=null)
        {
            await AttachToken();
            var url = "solicitudes" + (estado!=null? $"?estado={estado}": "");
            var res = await _http.GetAsync(url);
            res.EnsureSuccessStatusCode();
            var body = await res.Content.ReadAsStringAsync();
            return JsonSerializer.Deserialize<List<SolicitudItem>>(body, new JsonSerializerOptions{PropertyNameCaseInsensitive=true}) ?? new();
        }

        public async Task<bool> Aprobar(int id, string? comentario)
        {
            await AttachToken();
            var url = $"approvals/{id}/approve" + (comentario!=null? $"?comentario={Uri.EscapeDataString(comentario)}": "");
            var res = await _http.PostAsync(url, null);
            return res.IsSuccessStatusCode;
        }
        public async Task<bool> Rechazar(int id, string? comentario)
        {
            await AttachToken();
            var url = $"approvals/{id}/reject" + (comentario!=null? $"?comentario={Uri.EscapeDataString(comentario)}": "");
            var res = await _http.PostAsync(url, null);
            return res.IsSuccessStatusCode;
        }
    }
}
