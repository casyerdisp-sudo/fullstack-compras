/* ====== Creación de esquema base ====== */
IF DB_ID('ComprasInternasDB') IS NULL
BEGIN
  CREATE DATABASE ComprasInternasDB;
END
GO
USE ComprasInternasDB;
GO

/* Tablas */
IF OBJECT_ID('dbo.Usuarios') IS NOT NULL DROP TABLE dbo.Usuarios;
IF OBJECT_ID('dbo.Solicitudes') IS NOT NULL DROP TABLE dbo.Solicitudes;
IF OBJECT_ID('dbo.Auditoria') IS NOT NULL DROP TABLE dbo.Auditoria;
GO

CREATE TABLE dbo.Usuarios (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Username NVARCHAR(100) NOT NULL UNIQUE,
    PasswordHash NVARCHAR(255) NOT NULL,
    Rol NVARCHAR(20) NOT NULL CHECK (Rol IN ('Usuario','Supervisor')),
    Activo BIT NOT NULL DEFAULT 1,
    FechaCreacion DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
);

CREATE TABLE dbo.Solicitudes (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    UsuarioId INT NOT NULL FOREIGN KEY REFERENCES dbo.Usuarios(Id),
    Descripcion NVARCHAR(500) NOT NULL,
    Monto DECIMAL(18,2) NOT NULL,
    FechaEsperada DATE NOT NULL,
    Estado NVARCHAR(20) NOT NULL CHECK (Estado IN ('Pendiente','Aprobada','Rechazada')) DEFAULT 'Pendiente',
    ComentarioSupervisor NVARCHAR(500) NULL,
    FechaCreacion DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    FechaActualizacion DATETIME2 NULL
);

CREATE TABLE dbo.Auditoria (
    Id BIGINT IDENTITY(1,1) PRIMARY KEY,
    Usuario NVARCHAR(100) NOT NULL,
    Fecha DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    Accion NVARCHAR(100) NOT NULL,
    Detalle NVARCHAR(1000) NULL,
    Entidad NVARCHAR(50) NULL,
    EntidadId INT NULL
);
GO

/* Datos de prueba */
INSERT INTO dbo.Usuarios (Username, PasswordHash, Rol)
VALUES 
  ('empleado1', 'PLAINTEXT:empleado1', 'Usuario'),
  ('super1',    'PLAINTEXT:super1',    'Supervisor');
GO

/* Vista */
IF OBJECT_ID('dbo.v_solicitudes_por_usuario_estado') IS NOT NULL DROP VIEW dbo.v_solicitudes_por_usuario_estado;
GO
CREATE VIEW dbo.v_solicitudes_por_usuario_estado
AS
SELECT s.Id, s.UsuarioId, u.Username, s.Descripcion, s.Monto, s.FechaEsperada, s.Estado,
       s.ComentarioSupervisor, s.FechaCreacion, s.FechaActualizacion
FROM dbo.Solicitudes s
JOIN dbo.Usuarios u ON u.Id = s.UsuarioId;
GO

/* SP: Login */
IF OBJECT_ID('dbo.sp_login') IS NOT NULL DROP PROC dbo.sp_login;
GO
CREATE PROC dbo.sp_login
  @Username NVARCHAR(100),
  @Password NVARCHAR(255)
AS
BEGIN
  SET NOCOUNT ON;
  DECLARE @UserId INT, @Rol NVARCHAR(20), @Activo BIT, @PassDB NVARCHAR(255);
  SELECT @UserId = Id, @Rol = Rol, @Activo = Activo, @PassDB = PasswordHash
  FROM dbo.Usuarios WHERE Username=@Username;

  IF @UserId IS NULL OR @Activo = 0
  BEGIN
    RAISERROR('Usuario no encontrado o inactivo', 16, 1);
    RETURN;
  END

  IF LEFT(@PassDB,10)='PLAINTEXT:'
  BEGIN
    IF RIGHT(@PassDB, LEN(@PassDB)-10) <> @Password
    BEGIN
      RAISERROR('Credenciales inválidas', 16, 1); RETURN;
    END
  END
  ELSE
  BEGIN
    RAISERROR('Este entorno espera HASH. Ajuste API/DB.', 16, 1); RETURN;
  END

  INSERT INTO dbo.Auditoria (Usuario, Accion, Detalle)
  VALUES (@Username, 'LOGIN', 'Ingreso exitoso');

  SELECT Id=@UserId, Rol=@Rol, Username=@Username;
END
GO

/* SP: Crear solicitud */
IF OBJECT_ID('dbo.sp_crear_solicitud') IS NOT NULL DROP PROC dbo.sp_crear_solicitud;
GO
CREATE PROC dbo.sp_crear_solicitud
  @Username NVARCHAR(100),
  @Descripcion NVARCHAR(500),
  @Monto DECIMAL(18,2),
  @FechaEsperada DATE
AS
BEGIN
  SET NOCOUNT ON;
  DECLARE @UserId INT;
  SELECT @UserId = Id FROM dbo.Usuarios WHERE Username=@Username AND Activo=1;
  IF @UserId IS NULL BEGIN RAISERROR('Usuario inválido o inactivo',16,1); RETURN; END
  IF @Descripcion IS NULL OR LTRIM(RTRIM(@Descripcion))='' BEGIN RAISERROR('La descripción es obligatoria',16,1); RETURN; END
  IF @Monto IS NULL OR @Monto<=0 BEGIN RAISERROR('El monto debe ser > 0',16,1); RETURN; END
  IF @FechaEsperada IS NULL OR @FechaEsperada < CAST(GETDATE() AS DATE) BEGIN RAISERROR('La fecha esperada debe ser futura o actual',16,1); RETURN; END

  INSERT INTO dbo.Solicitudes (UsuarioId, Descripcion, Monto, FechaEsperada)
  VALUES (@UserId, @Descripcion, @Monto, @FechaEsperada);

  DECLARE @NewId INT = SCOPE_IDENTITY();
  INSERT INTO dbo.Auditoria (Usuario, Accion, Detalle, Entidad, EntidadId)
  VALUES (@Username, 'CREAR_SOLICITUD', CONCAT('Solicitud #', @NewId, ' creada'), 'Solicitud', @NewId);

  SELECT Id=@NewId;
END
GO

/* SP: Aprobar */
IF OBJECT_ID('dbo.sp_aprobar_solicitud') IS NOT NULL DROP PROC dbo.sp_aprobar_solicitud;
GO
CREATE PROC dbo.sp_aprobar_solicitud
  @SupervisorUsername NVARCHAR(100),
  @SolicitudId INT,
  @Comentario NVARCHAR(500) = NULL
AS
BEGIN
  SET NOCOUNT ON;
  DECLARE @SupRol NVARCHAR(20);
  SELECT @SupRol = Rol FROM dbo.Usuarios WHERE Username=@SupervisorUsername AND Activo=1;
  IF @SupRol IS NULL OR @SupRol <> 'Supervisor' BEGIN RAISERROR('Permisos insuficientes (se requiere Supervisor)',16,1); RETURN; END

  DECLARE @Monto DECIMAL(18,2), @Estado NVARCHAR(20);
  SELECT @Monto = Monto, @Estado = Estado FROM dbo.Solicitudes WHERE Id=@SolicitudId;
  IF @Monto IS NULL BEGIN RAISERROR('Solicitud inexistente',16,1); RETURN; END
  IF @Estado <> 'Pendiente' BEGIN RAISERROR('Solo se pueden aprobar solicitudes en estado Pendiente',16,1); RETURN; END

  IF @Monto > 5000 AND ( @Comentario IS NULL OR LTRIM(RTRIM(@Comentario))='' )
  BEGIN
    RAISERROR('Comentario obligatorio para montos > 5000',16,1); RETURN;
  END

  UPDATE dbo.Solicitudes
     SET Estado='Aprobada', ComentarioSupervisor=@Comentario, FechaActualizacion=SYSUTCDATETIME()
   WHERE Id=@SolicitudId;

  INSERT INTO dbo.Auditoria (Usuario, Accion, Detalle, Entidad, EntidadId)
  VALUES (@SupervisorUsername, 'APROBAR', CONCAT('Solicitud #', @SolicitudId, ' aprobada'), 'Solicitud', @SolicitudId);
END
GO

/* SP: Rechazar */
IF OBJECT_ID('dbo.sp_rechazar_solicitud') IS NOT NULL DROP PROC dbo.sp_rechazar_solicitud;
GO
CREATE PROC dbo.sp_rechazar_solicitud
  @SupervisorUsername NVARCHAR(100),
  @SolicitudId INT,
  @Comentario NVARCHAR(500) = NULL
AS
BEGIN
  SET NOCOUNT ON;
  DECLARE @SupRol NVARCHAR(20);
  SELECT @SupRol = Rol FROM dbo.Usuarios WHERE Username=@SupervisorUsername AND Activo=1;
  IF @SupRol IS NULL OR @SupRol <> 'Supervisor' BEGIN RAISERROR('Permisos insuficientes (se requiere Supervisor)',16,1); RETURN; END

  DECLARE @Estado NVARCHAR(20);
  SELECT @Estado = Estado FROM dbo.Solicitudes WHERE Id=@SolicitudId;
  IF @Estado IS NULL BEGIN RAISERROR('Solicitud inexistente',16,1); RETURN; END
  IF @Estado <> 'Pendiente' BEGIN RAISERROR('Solo se pueden rechazar solicitudes en estado Pendiente',16,1); RETURN; END

  UPDATE dbo.Solicitudes
     SET Estado='Rechazada', ComentarioSupervisor=@Comentario, FechaActualizacion=SYSUTCDATETIME()
   WHERE Id=@SolicitudId;

  INSERT INTO dbo.Auditoria (Usuario, Accion, Detalle, Entidad, EntidadId)
  VALUES (@SupervisorUsername, 'RECHAZAR', CONCAT('Solicitud #', @SolicitudId, ' rechazada'), 'Solicitud', @SolicitudId);
END
GO

/* SP: Listar */
IF OBJECT_ID('dbo.sp_listar_solicitudes') IS NOT NULL DROP PROC dbo.sp_listar_solicitudes;
GO
CREATE PROC dbo.sp_listar_solicitudes
  @Username NVARCHAR(100),
  @Estado NVARCHAR(20) = NULL
AS
BEGIN
  SET NOCOUNT ON;
  DECLARE @UserId INT, @Rol NVARCHAR(20);
  SELECT @UserId = Id, @Rol=Rol FROM dbo.Usuarios WHERE Username=@Username AND Activo=1;
  IF @UserId IS NULL BEGIN RAISERROR('Usuario inválido o inactivo',16,1); RETURN; END

  IF @Rol='Supervisor'
  BEGIN
    SELECT * FROM dbo.v_solicitudes_por_usuario_estado
      WHERE (@Estado IS NULL OR Estado=@Estado)
      ORDER BY FechaCreacion DESC;
  END
  ELSE
  BEGIN
    SELECT * FROM dbo.v_solicitudes_por_usuario_estado
      WHERE UsuarioId=@UserId AND (@Estado IS NULL OR Estado=@Estado)
      ORDER BY FechaCreacion DESC;
  END
END
GO
